package me.zombieapocalypse;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Husk;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityCombustByBlockEvent;
import org.bukkit.event.entity.EntityCombustByEntityEvent;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerBedEnterEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

public final class ZombieApocalypse extends JavaPlugin implements Listener, TabExecutor {

    private static final int DAY_TICKS = 24000;
    private static final Set<EntityType> REPLACED_MOBS = EnumSet.of(
            EntityType.SKELETON, EntityType.CREEPER, EntityType.SPIDER, EntityType.WITCH);

    private final Random rnd = new Random();
    private final Map<UUID, Location> lastPos = new HashMap<>();
    private final Map<UUID, Integer> stuck = new HashMap<>();

    private NamespacedKey zKey;
    private boolean active;
    private String worldName;
    private long startFullTime;
    private int lastDay = -1;
    private boolean lastBlood = false;

    // settings
    private int totalDays, bloodEvery, breakFromDay, spawnInterval, basePerPlayer, maxPerPlayer;
    private boolean breakDrops, allowSleep, replaceMobs;

    private BossBar bar;
    private BukkitTask mainTask, spawnTask, breakTask, fogTask;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        zKey = new NamespacedKey(this, "apocalypse_zombie");
        loadSettings();
        getServer().getPluginManager().registerEvents(this, this);
        var cmd = getCommand("zombieapocalypse");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        if (active && world() != null) {
            startTasks();
            getLogger().info("Zombie apocalypse resumed.");
        } else {
            active = false;
        }
    }

    @Override
    public void onDisable() {
        cancelTasks();
        saveState();
    }

    // ------------------------------------------------------------ settings/state

    private void loadSettings() {
        reloadConfig();
        var c = getConfig();
        totalDays = c.getInt("total-days", 100);
        bloodEvery = Math.max(1, c.getInt("blood-moon-every", 10));
        breakFromDay = c.getInt("block-break-from-day", 50);
        breakDrops = c.getBoolean("block-break-drops", false);
        allowSleep = c.getBoolean("allow-sleep", false);
        replaceMobs = c.getBoolean("replace-natural-mobs", true);
        spawnInterval = Math.max(10, c.getInt("spawn-interval-ticks", 40));
        basePerPlayer = c.getInt("base-zombies-per-player", 12);
        maxPerPlayer = c.getInt("max-zombies-per-player", 60);
        active = c.getBoolean("state.active", false);
        worldName = c.getString("state.world", "world");
        startFullTime = c.getLong("state.start", 0L);
    }

    private void saveState() {
        getConfig().set("state.active", active);
        getConfig().set("state.world", worldName);
        getConfig().set("state.start", startFullTime);
        saveConfig();
    }

    private World world() {
        return worldName == null ? null : Bukkit.getWorld(worldName);
    }

    private int currentDay(World w) {
        return (int) Math.floorDiv(w.getFullTime() - startFullTime, (long) DAY_TICKS) + 1;
    }

    private boolean isBlood(World w, int day) {
        long t = w.getTime();
        return day % bloodEvery == 0 && t >= 13000 && t < 23000;
    }

    // ------------------------------------------------------------ start / stop

    private void startApocalypse(World w) {
        worldName = w.getName();
        long full = w.getFullTime();
        long aligned = full - Math.floorMod(full, (long) DAY_TICKS);
        w.setFullTime(aligned); // day 1 begins at sunrise
        startFullTime = aligned;
        active = true;
        lastDay = -1;
        lastBlood = false;
        saveState();
        startTasks();
        for (Zombie z : w.getEntitiesByClass(Zombie.class)) {
            prepare(z);
        }
        Bukkit.broadcast(Component.text("☠ THE ZOMBIE APOCALYPSE HAS BEGUN! Survive " + totalDays + " days.",
                NamedTextColor.DARK_RED));
    }

    private void stopApocalypse(boolean removeZombies) {
        World w = world();
        active = false;
        cancelTasks();
        if (bar != null) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.hideBossBar(bar);
            }
        }
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.setWorldBorder(null);
        }
        if (removeZombies && w != null) {
            for (Zombie z : w.getEntitiesByClass(Zombie.class)) {
                if (isApoc(z)) z.remove();
            }
        }
        lastPos.clear();
        stuck.clear();
        saveState();
    }

    private void finish(World w) {
        Bukkit.broadcast(Component.text("★ YOU SURVIVED " + totalDays + " DAYS OF THE ZOMBIE APOCALYPSE! ★",
                NamedTextColor.GOLD));
        for (Player p : w.getPlayers()) {
            p.showTitle(Title.title(Component.text("YOU SURVIVED", NamedTextColor.GOLD),
                    Component.text(totalDays + " days of the apocalypse", NamedTextColor.YELLOW)));
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
        }
        stopApocalypse(true);
    }

    private void startTasks() {
        cancelTasks();
        bar = BossBar.bossBar(Component.text("Zombie Apocalypse"), 0f, BossBar.Color.PURPLE, BossBar.Overlay.PROGRESS);
        mainTask = Bukkit.getScheduler().runTaskTimer(this, this::tick, 20L, 20L);
        spawnTask = Bukkit.getScheduler().runTaskTimer(this, this::spawnTick, 40L, spawnInterval);
        breakTask = Bukkit.getScheduler().runTaskTimer(this, this::breakTick, 40L, 10L);
        fogTask = Bukkit.getScheduler().runTaskTimer(this, this::fogTick, 20L, 10L);
    }

    private void cancelTasks() {
        for (BukkitTask t : new BukkitTask[]{mainTask, spawnTask, breakTask, fogTask}) {
            if (t != null) t.cancel();
        }
        mainTask = spawnTask = breakTask = fogTask = null;
    }

    // ------------------------------------------------------------ main loop

    private void tick() {
        World w = world();
        if (w == null || !active) return;
        int day = currentDay(w);
        if (day > totalDays) {
            finish(w);
            return;
        }
        boolean blood = isBlood(w, day);
        boolean changed = false;

        if (day != lastDay) {
            lastDay = day;
            changed = true;
            announceDay(w, day);
        }
        if (blood != lastBlood) {
            lastBlood = blood;
            changed = true;
            announceBlood(w, blood);
        }
        if (changed) rescaleAll(w, day, blood);

        // fog-like weather: permanent storm, thunder during blood moon
        if (!w.hasStorm()) {
            w.setStorm(true);
            w.setWeatherDuration(24000);
        }
        if (w.isThundering() != blood) {
            w.setThundering(blood);
            w.setThunderDuration(12000);
        }

        // boss bar
        float progress = (float) Math.min(1.0, (day - 1 + w.getTime() / (double) DAY_TICKS) / totalDays);
        bar.name(blood
                ? Component.text("BLOOD MOON - Day " + day + "/" + totalDays, NamedTextColor.DARK_RED)
                : Component.text("Zombie Apocalypse - Day " + day + "/" + totalDays, NamedTextColor.LIGHT_PURPLE));
        bar.progress(Math.max(0f, progress));
        bar.color(blood ? BossBar.Color.RED : BossBar.Color.PURPLE);

        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getWorld().equals(w)) {
                p.showBossBar(bar);
                if (blood) applyRedVignette(p);
            } else {
                p.hideBossBar(bar);
            }
        }
    }

    private void announceDay(World w, int day) {
        String sub = day >= breakFromDay ? "Zombies can now break your blocks!" : "The dead grow stronger...";
        for (Player p : w.getPlayers()) {
            p.showTitle(Title.title(Component.text("Day " + day + " / " + totalDays, NamedTextColor.RED),
                    Component.text(sub, NamedTextColor.GRAY)));
        }
        if (day == breakFromDay) {
            Bukkit.broadcast(Component.text("⚠ From now on zombies can break blocks to reach you!",
                    NamedTextColor.RED));
        }
    }

    private void announceBlood(World w, boolean blood) {
        for (Player p : w.getPlayers()) {
            if (blood) {
                p.showTitle(Title.title(Component.text("BLOOD MOON", NamedTextColor.DARK_RED),
                        Component.text("They are faster. They are many.", NamedTextColor.RED)));
                p.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1f, 0.6f);
            } else {
                p.setWorldBorder(null);
                p.sendMessage(Component.text("The blood moon fades...", NamedTextColor.GRAY));
            }
        }
    }

    /** Red screen edge: a per-player huge-warning world border centered on the player. */
    private void applyRedVignette(Player p) {
        WorldBorder wb = Bukkit.createWorldBorder();
        wb.setCenter(p.getLocation());
        wb.setSize(2000);
        wb.setWarningDistance(100000);
        wb.setDamageAmount(0);
        wb.setDamageBuffer(1000);
        p.setWorldBorder(wb);
    }

    // ------------------------------------------------------------ zombie setup

    private boolean isApoc(Zombie z) {
        return z.getPersistentDataContainer().has(zKey, PersistentDataType.BYTE);
    }

    private void prepare(Zombie z) {
        z.getPersistentDataContainer().set(zKey, PersistentDataType.BYTE, (byte) 1);
        z.setRemoveWhenFarAway(false);
        z.setShouldBurnInDay(false);
        World w = z.getWorld();
        int day = Math.max(1, currentDay(w));
        scale(z, day, isBlood(w, day), true);
    }

    private void scale(Zombie z, int day, boolean blood, boolean heal) {
        double hp = 1 + day * 0.03;       // day 100 = 4x health
        double dmg = 1 + day * 0.02;      // day 100 = 3x damage
        double spd = Math.min(1.35, 1 + day * 0.0035) * (blood ? 1.15 : 1.0);
        setAttr(z, Attribute.MAX_HEALTH, hp);
        setAttr(z, Attribute.ATTACK_DAMAGE, dmg);
        setAttr(z, Attribute.MOVEMENT_SPEED, spd);
        AttributeInstance fr = z.getAttribute(Attribute.FOLLOW_RANGE);
        if (fr != null) fr.setBaseValue(64);
        if (heal) {
            AttributeInstance mh = z.getAttribute(Attribute.MAX_HEALTH);
            if (mh != null) z.setHealth(mh.getValue());
        }
    }

    private void setAttr(Zombie z, Attribute attr, double mult) {
        AttributeInstance ai = z.getAttribute(attr);
        if (ai != null) ai.setBaseValue(ai.getDefaultValue() * mult);
    }

    private void rescaleAll(World w, int day, boolean blood) {
        for (Zombie z : w.getEntitiesByClass(Zombie.class)) {
            if (isApoc(z)) scale(z, day, blood, false);
        }
    }

    // ------------------------------------------------------------ spawning

    private void spawnTick() {
        World w = world();
        if (w == null || !active) return;
        int day = currentDay(w);
        if (day < 1 || day > totalDays) return;
        boolean blood = isBlood(w, day);

        for (Player p : w.getPlayers()) {
            if (p.getGameMode() == org.bukkit.GameMode.SPECTATOR) continue;
            int cap = (int) Math.min(maxPerPlayer, basePerPlayer + day * 0.5);
            if (blood) cap = (int) (cap * 1.5);

            int count = 0;
            for (var e : p.getNearbyEntities(48, 32, 48)) {
                if (e instanceof Zombie z && isApoc(z)) count++;
            }
            if (count >= cap) continue;

            int toSpawn = Math.min(cap - count, 1 + day / 25 + (blood ? 3 : 0));
            for (int i = 0; i < toSpawn; i++) {
                Location l = findSpawn(w, p);
                if (l == null) continue;
                if (day >= 20 && rnd.nextDouble() < 0.2) {
                    spawnZ(l, Husk.class, p);
                } else {
                    spawnZ(l, Zombie.class, p);
                }
            }
        }
    }

    private <T extends Zombie> void spawnZ(Location l, Class<T> cls, Player target) {
        T z = l.getWorld().spawn(l, cls, this::prepare);
        z.setTarget(target);
    }

    private Location findSpawn(World w, Player p) {
        Location pl = p.getLocation();
        int py = pl.getBlockY();
        boolean underground = py < w.getHighestBlockYAt(pl) - 5;
        for (int attempt = 0; attempt < 12; attempt++) {
            double ang = rnd.nextDouble() * Math.PI * 2;
            double dist = 20 + rnd.nextDouble() * 20;
            int x = (int) Math.floor(pl.getX() + Math.cos(ang) * dist);
            int z = (int) Math.floor(pl.getZ() + Math.sin(ang) * dist);
            if (!w.isChunkLoaded(x >> 4, z >> 4)) continue;
            if (underground) {
                for (int y = py + 4; y >= py - 6; y--) {
                    if (validSpot(w, x, y, z)) return new Location(w, x + 0.5, y, z + 0.5);
                }
            } else {
                int y = w.getHighestBlockYAt(x, z) + 1;
                if (validSpot(w, x, y, z)) return new Location(w, x + 0.5, y, z + 0.5);
            }
        }
        return null;
    }

    private boolean validSpot(World w, int x, int y, int z) {
        Block below = w.getBlockAt(x, y - 1, z);
        Block feet = w.getBlockAt(x, y, z);
        Block head = w.getBlockAt(x, y + 1, z);
        return below.isSolid() && !below.isLiquid()
                && feet.isPassable() && !feet.isLiquid()
                && head.isPassable() && !head.isLiquid();
    }

    // ------------------------------------------------------------ block breaking (day 50+)

    private void breakTick() {
        World w = world();
        if (w == null || !active) return;
        int day = currentDay(w);
        if (day < breakFromDay) return;

        for (Zombie z : w.getEntitiesByClass(Zombie.class)) {
            if (!isApoc(z) || z.isDead()) continue;
            UUID id = z.getUniqueId();
            LivingEntity t = z.getTarget();
            if (!(t instanceof Player)) {
                stuck.remove(id);
                continue;
            }
            Location zl = z.getLocation();
            Location tl = t.getLocation();
            double dx = tl.getX() - zl.getX();
            double dz = tl.getZ() - zl.getZ();
            double dy = tl.getY() - zl.getY();
            double hd = Math.sqrt(dx * dx + dz * dz);
            Location prev = lastPos.put(id, zl);

            if (hd > 40 || (hd < 1.4 && Math.abs(dy) < 1.5)) {
                stuck.remove(id);
                continue;
            }
            boolean moved = prev != null && prev.getWorld() == w && prev.distanceSquared(zl) > 0.04;
            if (moved) {
                stuck.put(id, 0);
                continue;
            }
            int s = stuck.merge(id, 1, Integer::sum);
            if (s < 3) continue;

            Vector dir = hd > 0.01 ? new Vector(dx / hd, 0, dz / hd) : new Vector(0, 0, 0);
            Block feet = zl.clone().add(dir.multiply(0.9)).getBlock();
            Block head = feet.getRelative(0, 1, 0);
            Block self = zl.getBlock();

            List<Block> cands = new ArrayList<>();
            cands.add(feet);
            cands.add(head);
            if (dy > 1.5) {
                cands.add(self.getRelative(0, 2, 0));
                cands.add(head.getRelative(0, 1, 0));
            } else if (dy < -1.5) {
                cands.add(self.getRelative(0, -1, 0));
                cands.add(feet.getRelative(0, -1, 0));
            }
            for (Block b : cands) {
                if (breakable(b)) {
                    destroy(w, b);
                    stuck.put(id, 1); // next block after ~1 second
                    break;
                }
            }
        }
    }

    private boolean breakable(Block b) {
        if (b.isPassable() || b.isLiquid()) return false;
        Material m = b.getType();
        return m.getHardness() >= 0 && m.getBlastResistance() < 1200;
    }

    private void destroy(World w, Block b) {
        Location c = b.getLocation().add(0.5, 0.5, 0.5);
        w.spawnParticle(Particle.BLOCK, c, 20, 0.3, 0.3, 0.3, b.getBlockData());
        w.playSound(c, b.getBlockData().getSoundGroup().getBreakSound(), SoundCategory.BLOCKS, 1f, 0.8f);
        if (breakDrops) {
            b.breakNaturally();
        } else {
            b.setType(Material.AIR);
        }
    }

    // ------------------------------------------------------------ fog particles

    private void fogTick() {
        World w = world();
        if (w == null || !active) return;
        boolean blood = lastBlood;
        for (Player p : w.getPlayers()) {
            Location l = p.getLocation().add(0, 1.5, 0);
            p.spawnParticle(Particle.CLOUD, l, 14, 12, 3, 12, 0.0);
            p.spawnParticle(Particle.WHITE_ASH, l, 25, 10, 4, 10, 0.0);
            if (blood) {
                p.spawnParticle(Particle.DUST, l, 10, 10, 3, 10, 0,
                        new Particle.DustOptions(Color.fromRGB(150, 0, 0), 1.6f));
            }
        }
    }

    // ------------------------------------------------------------ events

    private boolean inApocWorld(World w) {
        return active && w != null && w.getName().equals(worldName);
    }

    @EventHandler
    public void onSpawn(CreatureSpawnEvent e) {
        if (!inApocWorld(e.getLocation().getWorld())) return;
        if (e.getEntity() instanceof Zombie z) {
            prepare(z);
        } else if (replaceMobs && e.getSpawnReason() == CreatureSpawnEvent.SpawnReason.NATURAL
                && REPLACED_MOBS.contains(e.getEntityType())) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onEntitiesLoad(EntitiesLoadEvent e) {
        if (!inApocWorld(e.getWorld())) return;
        for (var ent : e.getEntities()) {
            if (ent instanceof Zombie z) prepare(z);
        }
    }

    @EventHandler
    public void onCombust(EntityCombustEvent e) {
        if (!(e.getEntity() instanceof Zombie)) return;
        if (!inApocWorld(e.getEntity().getWorld())) return;
        if (e instanceof EntityCombustByEntityEvent || e instanceof EntityCombustByBlockEvent) return;
        e.setCancelled(true); // sunlight does not burn zombies
    }

    @EventHandler
    public void onDeath(EntityDeathEvent e) {
        lastPos.remove(e.getEntity().getUniqueId());
        stuck.remove(e.getEntity().getUniqueId());
    }

    @EventHandler
    public void onBed(PlayerBedEnterEvent e) {
        if (allowSleep || !inApocWorld(e.getPlayer().getWorld())) return;
        e.setCancelled(true);
        e.getPlayer().sendMessage(Component.text("You cannot sleep during the apocalypse!", NamedTextColor.RED));
    }

    // ------------------------------------------------------------ commands

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("apocalypse")) {
            args = Arrays.copyOfRange(args, 1, args.length);
        }
        if (args.length == 0) {
            sender.sendMessage(Component.text("Usage: /zombie apocalypse <start|stop|status|setday <n>|reload>",
                    NamedTextColor.YELLOW));
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "start" -> {
                if (active) {
                    sender.sendMessage(Component.text("Apocalypse is already running.", NamedTextColor.RED));
                    return true;
                }
                World w = (sender instanceof Player p && p.getWorld().getEnvironment() == World.Environment.NORMAL)
                        ? p.getWorld() : Bukkit.getWorlds().get(0);
                startApocalypse(w);
            }
            case "stop" -> {
                if (!active) {
                    sender.sendMessage(Component.text("Apocalypse is not running.", NamedTextColor.RED));
                    return true;
                }
                stopApocalypse(true);
                Bukkit.broadcast(Component.text("The zombie apocalypse has been stopped.", NamedTextColor.GREEN));
            }
            case "status" -> {
                World w = world();
                if (!active || w == null) {
                    sender.sendMessage(Component.text("Apocalypse is not running.", NamedTextColor.GRAY));
                    return true;
                }
                int day = currentDay(w);
                long zc = w.getEntitiesByClass(Zombie.class).stream().filter(this::isApoc).count();
                sender.sendMessage(Component.text("Day " + day + "/" + totalDays
                        + " | Blood moon: " + isBlood(w, day) + " | Zombies: " + zc, NamedTextColor.YELLOW));
            }
            case "setday" -> {
                World w = world();
                if (!active || w == null || args.length < 2) {
                    sender.sendMessage(Component.text("Usage (while running): /zombie apocalypse setday <n>",
                            NamedTextColor.RED));
                    return true;
                }
                try {
                    int n = Math.max(1, Integer.parseInt(args[1]));
                    long full = w.getFullTime();
                    long aligned = full - Math.floorMod(full, (long) DAY_TICKS);
                    startFullTime = aligned - (long) (n - 1) * DAY_TICKS;
                    lastDay = -1;
                    saveState();
                    sender.sendMessage(Component.text("Day set to " + n, NamedTextColor.GREEN));
                } catch (NumberFormatException ex) {
                    sender.sendMessage(Component.text("Invalid number.", NamedTextColor.RED));
                }
            }
            case "reload" -> {
                boolean was = active;
                loadSettings();
                active = was;
                sender.sendMessage(Component.text("Config reloaded.", NamedTextColor.GREEN));
            }
            default -> sender.sendMessage(Component.text("Unknown subcommand.", NamedTextColor.RED));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> opts = List.of("start", "stop", "status", "setday", "reload");
        if (args.length == 1) {
            List<String> first = new ArrayList<>(opts);
            first.add("apocalypse");
            return filter(first, args[0]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("apocalypse")) {
            return filter(opts, args[1]);
        }
        return List.of();
    }

    private List<String> filter(List<String> list, String prefix) {
        List<String> out = new ArrayList<>();
        for (String s : list) {
            if (s.startsWith(prefix.toLowerCase())) out.add(s);
        }
        return out;
    }
}
